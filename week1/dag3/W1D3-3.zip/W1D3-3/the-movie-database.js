let movieDatabase = function(title, duration, stars) {
  console.log(
    title + " lasts for " + duration + " minutes. " + "Stars: " + stars
  );
};
movieDatabase("Terminator", 120, ["Brad Pitt", "George Clooney", "Leonardo"]);
