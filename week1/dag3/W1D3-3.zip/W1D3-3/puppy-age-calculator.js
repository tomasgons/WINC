const dogYears = function(age) {
  let dogYears = 7 * age;
  console.log("Your doggie is " + dogYears + " years old in dog years!");
};

dogYears("5");
dogYears("3");
dogYears("10");
