// Multiplication tables
var multiplier = 9;
for (var i = 0; i <= 10; i++) {
  var result = multiplier * i;
  console.log(multiplier + " * " + i + " = " + result);
}
