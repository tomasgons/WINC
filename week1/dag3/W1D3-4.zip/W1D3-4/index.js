let age = 5;
while (age < 10) {
  console.log("Your age is less then 10");
  age++;
  document.write("You are onow over 10");
}
