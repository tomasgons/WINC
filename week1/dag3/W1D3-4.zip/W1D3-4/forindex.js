for (age = 0; age > 10; age++) {
  console.log("Your age is less then 10");

  document.write("You are onow over 10");
}
