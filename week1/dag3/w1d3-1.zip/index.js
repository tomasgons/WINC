let person = {
  name: "Tomas",
  age: 42,
  evaluations: [7, 9, 10]
};

console.log(person.evaluations);
